# AURA phone-first web app

This is a mobile-friendly PWA-style frontend.

It works as a local/static interface, but real AI responses require a secure `/api/chat` backend.
Do NOT put an OpenAI API key in this frontend.

The backend should call the OpenAI API server-side. OpenAI's platform provides the API used for building applications. 

To use this as a home-screen web app, it needs to be hosted over HTTPS (or served locally during development).
